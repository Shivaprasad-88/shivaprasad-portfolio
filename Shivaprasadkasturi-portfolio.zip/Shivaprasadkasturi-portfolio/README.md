# Kasturi Shivaprasad — Portfolio

A responsive, cinematic single-page portfolio inspired by the uploaded red-and-black 3D portfolio reference.

## Run locally

No build step or package install is required. Open `index.html` in a browser, or run a local static server:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy to Netlify

- Build command: leave blank
- Publish directory: `.`
- The included `netlify.toml` configures the publish directory.

## Deploy to GitHub Pages

For a repository named `Shivaprasadkasturi-portfolio`, enable GitHub Pages from the `main` branch and select the root folder.

## Contact

The main contact link currently opens the LinkedIn profile. Replace it with a preferred public contact address when ready.
